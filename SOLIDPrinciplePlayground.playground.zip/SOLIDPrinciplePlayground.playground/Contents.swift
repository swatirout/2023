import UIKit
import Foundation
//Single Responsibility
struct Person {
    let name: String
    let age: Int
}

struct AgeVaidator{
    func checkAge(val: Int) -> String {
        if val < 8 {
            return "Underage"
        } else {
            return "Qualified"
        }
    }
}

let person = Person(name: "Swati",age: 10)
let verifyAge = AgeVaidator()

verifyAge.checkAge(val: person.age)

//Open Closed
protocol Animal {
    func makeSound () -> String
    
}

class Tiger: Animal {
    func makeSound() -> String {
        return "Roar"
    }
}

struct Zoo {
    let animals: [Animal]
    func animalNoise() -> [String] {
        return animals.map{ $0.makeSound ()}
    }
}

let tiger = Tiger()
var zooAnimals = Zoo(animals: [tiger])
zooAnimals.animalNoise()

class Horse: Animal {
    func makeSound() -> String {
        return "Hoo"
    }
}

let horse = Horse()
var zooAnimalss = Zoo(animals: [tiger,horse])
zooAnimalss.animalNoise()

//Liskov Substitution

class Bird{
    func makeNoise() {
        print("Chirp Chirp")
    }
}

class Eagle: Bird {
    override func makeNoise() {
        print("Eagle Eagle")
    }
}
///below breaks this principle

class Crow: Bird {
    override func makeNoise() {
        fatalError("I wont chirp")
    }
}

//Interface Segregation
protocol EatAction {
  func eat()
}
protocol WorkAction {
  func work()
}
class Adult: EatAction, WorkAction {
  func eat() {
    // adut eat
  }
  func work() {
    // adult work
  }
}
class Baby: EatAction {
  func eat() {
    // baby eat
  }
}
// Dependency Inversion
protocol Database {
  func connect()
}

class DatabaseController {
  private let database: Database
  
  init(db: Database) {
    self.database = db
}
  func connectDatabase() {
    database.connect()
  }
}
class NetworkRequest: Database {
  func connect() {
    // Connect to the database
  }
}
